# setup.py
from setuptools import setup, find_packages

setup(
    name='d2l',
    version='0.1.0',
    packages=find_packages(),
)
